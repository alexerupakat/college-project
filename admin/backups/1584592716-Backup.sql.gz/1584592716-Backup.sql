-- ---------------------------------------------------------
--
--
-- Host Connection Info: localhost:3306 via TCP/IP
-- Generation Time: March 19, 2020 at 04:38 AM ( UTC )
-- Server version: 5.7.26
-- PHP Version: 7.2.18
--
-- ---------------------------------------------------------


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `admin`
--
-- ---------------------------------------------------------
CREATE TABLE `admin` (
  `admin_id` int(4) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(10) COLLATE utf32_unicode_ci NOT NULL,
  `admin_password` varchar(10) COLLATE utf32_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf32_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `admin_username` (`admin_username`)
) ENGINE=MyISAM AUTO_INCREMENT=1002 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `admin`
--
INSERT INTO `admin` (`admin_id`, `admin_username`, `admin_password`, `email`) VALUES
(1001, 'admin', 'admin', 'admin@gmail.com');



-- ---------------------------------------------------------
--
-- Table structure for table : `booking`
--
-- ---------------------------------------------------------
CREATE TABLE `booking` (
  `booking_id` int(4) NOT NULL AUTO_INCREMENT,
  `booking_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `customer_id` int(4) NOT NULL,
  `bus_id` int(4) NOT NULL,
  `payment_id` int(4) DEFAULT NULL,
  `route_id` int(4) NOT NULL,
  `booking_status` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2024 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `booking`
--
INSERT INTO `booking` (`booking_id`, `booking_date`, `customer_id`, `bus_id`, `payment_id`, `route_id`, `booking_status`) VALUES
(2004, '2020-03-17 15:26:14', 4004, 3001, 97238456, 8004, 'BOOKING_CANCELLED'),
(2003, '2020-03-17 14:58:37', 4004, 3001, 87410881, 8004, 'Payment in process'),
(2005, '2020-03-17 15:26:24', 4004, 3001, 1007239, 8004, 'BOOKING_CANCELLED'),
(2006, '2020-03-17 14:58:37', 4004, 3001, 45169619, 8004, 'Payment in process'),
(2007, '2020-03-17 15:26:29', 4004, 3001, 34908468, 8004, 'BOOKING_CANCELLED'),
(2008, '2020-03-17 15:26:35', 4004, 3001, 39148636, 8004, 'BOOKING_CANCELLED'),
(2009, '2020-03-17 15:25:26', 4004, 3001, 10072764, 8004, 'BOOKING_CANCELLED'),
(2010, '2020-03-17 14:58:37', 4003, 3000, 42399669, 8003, 'Payment in process'),
(2011, '2020-03-17 14:58:37', 4003, 3000, 3762371, 8003, 'Payment in process'),
(2012, '2020-03-17 14:58:37', 4004, 3001, 67904710, 8004, 'Payment in process'),
(2013, '2020-03-17 14:58:37', 4004, 3001, 97934782, 8004, 'Payment in process'),
(2014, '2020-03-17 14:58:37', 4004, 3001, 57101527, 8004, 'Payment in process'),
(2015, '2020-03-17 14:58:37', 4032, 3006, 33293218, 8008, 'Payment in process'),
(2016, '2020-03-17 14:58:37', 4032, 3001, 48613745, 8004, 'Payment in process'),
(2017, '2020-03-17 14:58:37', 4004, 3001, 41115975, 8004, 'Payment in process'),
(2018, '2020-03-17 14:58:37', 4004, 3001, 24187460, 8004, 'Payment in process'),
(2019, '2020-03-17 14:58:37', 4004, 3001, 22535397, 8004, 'Payment in process'),
(2020, '2020-03-17 14:58:37', 4004, 3001, 46217679, 8004, 'Payment in process'),
(2021, '2020-03-17 15:26:32', 4004, 3001, 16388894, 8004, 'BOOKING_CANCELLED'),
(2022, '2020-03-18 21:55:23', 4032, 3000, 67452449, 8003, 'PAYMENT_IN PROCESS'),
(2023, '2020-03-18 21:57:38', 4032, 3000, 87436608, 8003, 'PAYMENT_SUCCESS');



-- ---------------------------------------------------------
--
-- Table structure for table : `bus`
--
-- ---------------------------------------------------------
CREATE TABLE `bus` (
  `bus_id` int(4) NOT NULL AUTO_INCREMENT,
  `agency_id` int(4) NOT NULL,
  `route_id` int(4) NOT NULL,
  `bus_name` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `bus_no` varchar(15) COLLATE utf32_unicode_ci NOT NULL,
  `img_loc` varchar(40) COLLATE utf32_unicode_ci NOT NULL,
  `chasis_no` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `seating` int(2) NOT NULL,
  `price` varchar(2) COLLATE utf32_unicode_ci NOT NULL,
  `ac_or_non_ac` int(1) NOT NULL,
  `sleeper_or_non` int(1) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3016 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `bus`
--
INSERT INTO `bus` (`bus_id`, `agency_id`, `route_id`, `bus_name`, `bus_no`, `img_loc`, `chasis_no`, `seating`, `price`, `ac_or_non_ac`, `sleeper_or_non`) VALUES
(3000, 9000, 8003, 'Fahima', 'KA 21 H 6897', '5e53e5524b3e51.png', 'FGJ1763567', 45, 10, 0, 1),
(3001, 9014, 8004, 'Cadbury', 'KA 19 H 6786', '5e54dcd1c59b42.png', 'AKE9865679', 50, 13, 0, 1),
(3002, 9007, 8002, 'Bharath', 'KA 21 G 1234', '5e54dd684649b3.png', 'HGF87456987', 52, 15, 0, 0),
(3003, 9012, 8009, 'Salalah', 'KA 21 G 6678', '5e54de052e9654.png', 'HYT3456789', 54, 15, 0, 0),
(3004, 9011, 8010, 'Nirmala', 'KA 19 Y 7890', '5e5533d24aed35.png', 'MA6MFBC1BBT096358', 54, 12, 0, 1),
(3005, 9014, 8014, 'Cadbury', 'KA 21 J 6780', '5e553414bb7c86.png', 'MA6MFBC1BBT096358', 51, 14, 1, 1),
(3006, 9009, 8008, 'Skanda', 'KA 21 K 9584', '5e55344eee7967.png', 'MA6MFBC1BBT096358', 58, 21, 0, 0),
(3007, 9015, 8012, 'Kanda', 'KA 19 K 4567', '5e553475a2a428.png', 'MA6MFBC1BBT096358', 50, 13, 0, 0),
(3008, 9002, 8007, 'Netcom', 'KA 18 M 7667', '5e55349de31b69.png', 'MA6MFBC1BBT096358', 45, 10, 1, 1),
(3010, 9007, 8012, 'Bharath', 'KA 54 H 5678', '5e5535575b28910.png', 'MA6MFBC1BBT096358', 50, 20, 0, 0),
(3011, 9013, 8005, 'Safwan', 'KA 32 H 7819', '5e55357ba87c711.png', 'MA6MFBC1BBT096358', 45, 23, 0, 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `customer`
--
-- ---------------------------------------------------------
CREATE TABLE `customer` (
  `customer_id` int(4) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `customer_email` varchar(30) COLLATE utf32_unicode_ci NOT NULL,
  `customer_phone` varchar(15) COLLATE utf32_unicode_ci NOT NULL,
  `customer_password` varchar(15) COLLATE utf32_unicode_ci NOT NULL,
  `customer_address` text COLLATE utf32_unicode_ci NOT NULL,
  `customer_state` varchar(15) COLLATE utf32_unicode_ci NOT NULL,
  `customer_city` varchar(15) COLLATE utf32_unicode_ci NOT NULL,
  `customer_pincode` int(7) NOT NULL,
  `verified` int(1) NOT NULL DEFAULT '0',
  `verification_code` varchar(20) COLLATE utf32_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customer_phone` (`customer_phone`)
) ENGINE=MyISAM AUTO_INCREMENT=4033 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `customer`
--
INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_password`, `customer_address`, `customer_state`, `customer_city`, `customer_pincode`, `verified`, `verification_code`) VALUES
(4003, 'Alex Thomas', 'alexthomas@gmail.com', 9745465478, 'alexthomas', 'Erupkat, Kerala', 'Karnataka', 'Erupakat', 524135, 0, ''),
(4004, 'John', 'john@gmail.com', 8745465874, 'john', 'Darbe, Puttur', 'Karnataka', 'Puttur', 574202, 0, ''),
(4005, 'Ajay', 'ajay@gmail.com', 8745698745, 'ajay', 'Sullia', 'Karnataka', 'Sullia', 574688, 0, ''),
(4006, 'Karan', 'karan@gmail.com', 8745765489, 'karan', 'Manglore', 'Karnataka', 'Manglore', 587467, 0, ''),
(4007, 'Varun', 'varun@gmail.com', 7458746987, 'varun', 'Hasan', 'Karnataka', 'Hasan', 574687, 0, ''),
(4008, 'Tharun', 'tharun@gmail.com', 8745874598, 'tharun', 'Madikeri', 'Karnataka', 'Madikeri', 546745, 0, ''),
(4009, ' Sachin', 'sachin@gmail.com', 9874574517, 'sachin', 'Darbe, Puttur', 'Karnataka', 'Puttur', 574645, 0, ''),
(4010, 'Virat Kohli', 'viratkohli@gmail.com', 874587456, 'viratkohli', 'Peraje, Madikeri', 'Karnataka', 'Madikeri', 512745, 0, ''),
(4011, 'MS Dhoni', 'msdhoni@gmail.com', 574687, 'msdhoni', 'Mysore', 'Karnataka', 'Mysore', 536457, 0, ''),
(4012, 'Bhavan', 'bhavan@gmail.com', 8745874589, 'bhavan', ',Kodaibail, Manglore', 'Manglore', 874568745, 587468, 0, ''),
(4013, 'Kumar', 'kumar@gmail.com', 8745874568, 'kumar', 'Darbe, Puttur', 'Karnataka', 'Puttur', 574786, 0, ''),
(4014, 'Rakesh', 'rakesh@gmail.com', 8745874597, 'rakesh', 'Darbe, Puttur', 'Karnataka', 'Puttur', 574658, 0, ''),
(4015, 'Krishna', 'krishna@gmail.com', 987412544, 'krishna', 'Darbe, Puttur', 'Karnataka', 'Puttur', 569874, 0, ''),
(4016, 'Rajesh', 'rajesh@gmail.com', 123, 'rajesh', 'Sullia', 'Karntaka', 'Sullia', 564345, 0, ''),
(4017, 'Jason', 'jason@gmail.com', 8971789518, 'abc', 'Beeramale', 'Karnataka', 'Puttur', 574202, 0, ''),
(4018, 'Jason', 'jason@gmail.com', 9449533060, 'abc', 'Puttur', 'Karnataka', 'Puttur', 574202, 0, ''),
(4019, 'asrt', 'a@gmail.com', 9535693848, 'abc', 'kjh', 'kjh', 'kj', 646, 0, ''),
(4023, 'sef', 'a@gmail.com', 7026396908, 'abc', 'kj', 'jh', 'l', 8768, 0, ''),
(4024, 'Lashmitha', 'lashmitha@gmail.com', 9483727300, 'lashmitha', 'Periyapatna', 'Karnataka', 'Periypatna', 574654, 0, ''),
(4025, 'dfg', 'a@gmail.com', 766587, 123, 'uhb', 'jhb', 'jkhb', 65476, 0, ''),
(4026, 'wef', 'a@gmail.com', 564, 123, 'jkhjk', 'kjb', 'jh', 456, 0, ''),
(4027, 'wef', 'a@gmail.com', 675, 123, 'kjj', 'kjbk', 'kljb', 76, 0, ''),
(4028, 'AWDF', 'a@gmail.com', 765, 123, 'jkg', 'ghkj', 'iigh', 66789, 0, ''),
(4029, 'Mokshith', 'a@gmail.com', 4567890, 123, 'jgf', 'kjb', 'khjk', 456, 0, ''),
(4032, 'Mokshith', 'mokshithgowda2903@gmail.com', 6363561765, 123, 'Sullia', 'Karnataka', 'Sullia', 574314, 0, '5e70a44b02e54');



-- ---------------------------------------------------------
--
-- Table structure for table : `newsletter`
--
-- ---------------------------------------------------------
CREATE TABLE `newsletter` (
  `newsletter_id` int(4) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf32_unicode_ci NOT NULL,
  `last_name` text COLLATE utf32_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf32_unicode_ci NOT NULL,
  `phone` int(15) NOT NULL,
  `message` text COLLATE utf32_unicode_ci NOT NULL,
  PRIMARY KEY (`newsletter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5007 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `newsletter`
--
INSERT INTO `newsletter` (`newsletter_id`, `name`, `last_name`, `email`, `phone`, `message`) VALUES
(5001, 'Mokshith', 'Gowda', 'mokshith@gmail.com', 874558745, 'Hello'),
(5002, 'Alex', 'Thomas', 'alex@gmail.com', 874598745, 'Hii'),
(5003, 'Mathew', 'M G', 'mathew@gmail.com', 87458745, 'Hello'),
(5004, 'Varun', 'A', 'varun@gmail.com', 87455984, 'Hello'),
(5005, 'Arun', 'H ', 'arun@gmail.com', 87455597, 'Hii'),
(5006, 'dty', 'd', 'a@gmail.com', 234, 'df');



-- ---------------------------------------------------------
--
-- Table structure for table : `notify`
--
-- ---------------------------------------------------------
CREATE TABLE `notify` (
  `norify_id` int(4) NOT NULL AUTO_INCREMENT,
  `admin` varchar(20) COLLATE utf32_unicode_ci DEFAULT NULL,
  `agency` varchar(20) COLLATE utf32_unicode_ci DEFAULT NULL,
  `email` varchar(30) COLLATE utf32_unicode_ci NOT NULL,
  `subject` text COLLATE utf32_unicode_ci NOT NULL,
  `message` text COLLATE utf32_unicode_ci NOT NULL,
  `notify_to` int(4) NOT NULL,
  PRIMARY KEY (`norify_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6009 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `notify`
--
INSERT INTO `notify` (`norify_id`, `admin`, `agency`, `email`, `subject`, `message`, `notify_to`) VALUES
(6001, 'admin', '', 'littleflower@gmail.com', 'Booking', 'Booking Confirmed', 9002),
(6002, 'admin', '', 'littleflower@gmail.com', 'Booking', 'Booking Confirmed', 9005),
(6003, 'admin', '', 'littleflower@gmail.com', 'Booking', 'Booking Confirmed', 9009),
(6004, 'admin', '', 'littleflower@gmail.com', 'Booking', 'Booking Confirmed', 9010),
(6005, 'admin', '', 'littleflower@gmail.com', 'Booking', 'Booking Confirmed', 9014),
(6006, 'admin', '', 'mokshith@gmail.com', 'ergf', 'sadf', 4001),
(6007, 'admin', '', 'fahima@gmail.com', 'Hello', 'Hello Hii', 9000),
(6008, 'admin', '', 'mokshith@gmail.com', 'hii', 'hello', 4002);



-- ---------------------------------------------------------
--
-- Table structure for table : `payment`
--
-- ---------------------------------------------------------
CREATE TABLE `payment` (
  `payment_id` int(4) NOT NULL AUTO_INCREMENT,
  `customer_id` int(4) NOT NULL,
  `amount` varchar(10) COLLATE utf32_unicode_ci NOT NULL,
  `status` text COLLATE utf32_unicode_ci,
  `payment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=97934783 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `payment`
--
INSERT INTO `payment` (`payment_id`, `customer_id`, `amount`, `status`, `payment_date`) VALUES
(97238456, 4004, 10502, '', '2020-03-16 05:26:06'),
(87410881, 4004, 10002, '', '2020-03-16 05:26:06'),
(1007239, 4004, 16002, '', '2020-03-16 05:26:06'),
(45169619, 4004, 33502, '', '2020-03-16 05:26:06'),
(34908468, 4004, 21002, '', '2020-03-16 05:26:06'),
(39148636, 4004, 9502, '', '2020-03-16 05:26:06'),
(10072764, 4004, 9002, 'TXN_SUCCESS', '2020-03-16 05:26:06'),
(42399669, 4003, 3750, 'TXN_SUCCESS', '2020-03-16 05:26:06'),
(3762371, 4003, 3250, 'TXN_SUCCESS', '2020-03-16 05:26:06'),
(67904710, 4004, 9002, 'TXN_FAILURE', '2020-03-16 05:26:06'),
(97934782, 4004, 9002, 'TXN_SUCCESS', '2020-03-16 11:05:53'),
(57101527, 4004, 9502, 'TXN_SUCCESS', '2020-03-16 11:26:01'),
(33293218, 4032, 32882, '', '2020-03-16 15:22:26'),
(48613745, 4032, 9002, 'TXN_SUCCESS', '2020-03-16 15:45:36'),
(41115975, 4004, 9502, '', '2020-03-16 21:10:13'),
(24187460, 4004, 9502, '', '2020-03-16 21:10:25'),
(22535397, 4004, 9502, '', '2020-03-16 21:10:28'),
(46217679, 4004, 9502, '', '2020-03-16 21:10:34'),
(16388894, 4004, 9502, '', '2020-03-16 21:12:39'),
(67452449, 4032, 4250, '', '2020-03-18 21:55:23'),
(87436608, 4032, 4250, 'TXN_SUCCESS', '2020-03-18 21:57:38');



-- ---------------------------------------------------------
--
-- Table structure for table : `refund`
--
-- ---------------------------------------------------------
CREATE TABLE `refund` (
  `refund_id` int(4) NOT NULL AUTO_INCREMENT,
  `booking_id` int(4) NOT NULL,
  `customer_id` int(4) NOT NULL,
  `amount` int(10) NOT NULL,
  PRIMARY KEY (`refund_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `refund`
--
INSERT INTO `refund` (`refund_id`, `booking_id`, `customer_id`, `amount`) VALUES
(1, 234, 234, 23423),
(2, 234, 234, 23423),
(3, 2008, 4004, 9502),
(4, 2006, 4004, 33502),
(5, 2003, 4004, 10002),
(6, 2006, 4004, 33502),
(7, 2007, 4004, 21002),
(8, 2008, 4004, 9502),
(9, 2005, 4004, 14402),
(10, 2009, 4004, 8102),
(11, 2005, 4004, 14402),
(12, 2007, 4004, 18902),
(13, 2005, 4004, 14402),
(14, 2021, 4004, 8552),
(15, 2009, 4004, 8102),
(16, 2005, 4004, 14402),
(17, 2009, 4004, 8102),
(18, 2004, 4004, 9452),
(19, 2005, 4004, 14402),
(20, 2007, 4004, 18902),
(21, 2021, 4004, 8552),
(22, 2008, 4004, 8552);



-- ---------------------------------------------------------
--
-- Table structure for table : `route`
--
-- ---------------------------------------------------------
CREATE TABLE `route` (
  `route_id` int(4) NOT NULL AUTO_INCREMENT,
  `route_source` text COLLATE utf32_unicode_ci NOT NULL,
  `route_destination` text COLLATE utf32_unicode_ci NOT NULL,
  `route_km` varchar(5) COLLATE utf32_unicode_ci NOT NULL,
  PRIMARY KEY (`route_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8016 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `route`
--
INSERT INTO `route` (`route_id`, `route_source`, `route_destination`, `route_km`) VALUES
(8001, 'Puttur', 'Manglore', 51),
(8002, 'Madikeri', 'Manglore', 145),
(8003, 'Mysore', 'Banglore', 325),
(8004, 'Puttur', 'Banglore', 654),
(8005, 'Manglore', 'Banglore', 354),
(8006, 'Madikeri', 'Banglore', 451),
(8007, 'Hasan', 'Banglore', 687),
(8008, 'Dehli', 'Puttur', 1542),
(8009, 'Puttur', 'Hasan', 547),
(8012, 'Sullia', 'Hasan', 587),
(8013, 'Shivamogga', 'Banglore', 987),
(8014, 'Shivamogga', 'Manglore', 574),
(8015, 'Shivamogga', 'Manglore', 587);



-- ---------------------------------------------------------
--
-- Table structure for table : `travel_agency`
--
-- ---------------------------------------------------------
CREATE TABLE `travel_agency` (
  `agency_id` int(4) NOT NULL AUTO_INCREMENT,
  `agency_name` varchar(30) COLLATE utf32_unicode_ci NOT NULL,
  `agency_address` text COLLATE utf32_unicode_ci NOT NULL,
  `agency_state` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `agency_city` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `agency_pincode` varchar(7) COLLATE utf32_unicode_ci NOT NULL,
  `agency_email` varchar(30) COLLATE utf32_unicode_ci NOT NULL,
  `agency_password` varchar(20) COLLATE utf32_unicode_ci NOT NULL,
  `verified` int(1) NOT NULL DEFAULT '0',
  `verification_code` varchar(20) COLLATE utf32_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`agency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9016 DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `travel_agency`
--
INSERT INTO `travel_agency` (`agency_id`, `agency_name`, `agency_address`, `agency_state`, `agency_city`, `agency_pincode`, `agency_email`, `agency_password`, `verified`, `verification_code`) VALUES
(9000, 'Fahima Tours and Travels', 'Sullia, Karnataka', 'Karnataka', 'Sullia', 574239, 'fahima@gmail.com', 'fahima1', 0, ''),
(9001, 'Easy Mart Travels', 'Panathur, Kerala', 'Kerala', 'Panathur', 587987, 'easymart@gmail.com', 'easymart', 0, ''),
(9002, 'Netcom Travels	', 'Sullia, Karnataka', 'Karnataka', 'Sullia', 574239, 'netcom@gmail.com', 'netcom', 0, ''),
(9003, 'Star Tours and Travels	', 'Ninthikallu, Karnataka', 'Karnataka', 'Sullia', 574321, 'startours@gmail.com', 'startours', 0, ''),
(9004, 'Coorg Travels', 'Madikeri, Karnataka', 'Karnataka', 'Madikeri', 576547, 'coorgtravels@gmail.com', 'coorgtravels', 0, ''),
(9005, 'Travel Club service', 'Subramanya, Karnataka', 'Karnataka', 'Subramanya', 574654, 'travelclub@gmail.com', 'travelclub', 0, ''),
(9006, 'Coors S R Tours and Travels ', 'Madikeri, Karnataka', 'Karnataka', 'Madikeri', 574654, 'coorgsr@gmail.com', 'coorgsr', 0, ''),
(9007, 'Bharath Travels ', 'Mangalore, Karnataka', 'Karnataka', 'Mangalore', 587465, 'bharathtravels@gmail.com', 'bharath', 0, ''),
(9008, 'Coorg Holiday Makers	', 'Madikeri, Karnataka', 'Karnataka', 'Madikeri', 574874, 'coorgholiday@gmail.com', 'coorgholiday', 0, '');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;